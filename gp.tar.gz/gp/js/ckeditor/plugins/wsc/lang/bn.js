﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'bn', {
	btnIgnore: 'ইগনোর কর',
	btnIgnoreAll: 'সব ইগনোর কর',
	btnReplace: 'বদলে দাও',
	btnReplaceAll: 'সব বদলে দাও',
	btnUndo: 'আন্ডু',
	changeTo: 'এতে বদলাও',
	errorLoading: 'Error loading application service host: %s.',
	ieSpellDownload: 'বানান পরীক্ষক ইনস্টল করা নেই। আপনি কি এখনই এটা ডাউনলোড করতে চান?',
	manyChanges: 'বানান পরীক্ষা শেষ: %1 গুলো শব্দ বদলে গ্যাছে',
	noChanges: 'বানান পরীক্ষা শেষ: কোন শব্দ পরিবর্তন করা হয়নি',
	noMispell: 'বানান পরীক্ষা শেষ: কোন ভুল বানান পাওয়া যায়নি',
	noSuggestions: '- কোন সাজেশন নেই -',
	notAvailable: 'Sorry, but service is unavailable now.',
	notInDic: 'শব্দকোষে নেই',
	oneChange: 'বানান পরীক্ষা শেষ: একটি মাত্র শব্দ পরিবর্তন করা হয়েছে',
	progress: 'বানান পরীক্ষা চলছে...',
	title: 'Spell Checker',
	toolbar: 'বানান চেক'
});
