﻿/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'format', 'ca', {
	label: 'Format',
	panelTitle: 'Format',
	tag_address: 'Adreça',
	tag_div: 'Normal (DIV)',
	tag_h1: 'Encapçalament 1',
	tag_h2: 'Encapçalament 2',
	tag_h3: 'Encapçalament 3',
	tag_h4: 'Encapçalament 4',
	tag_h5: 'Encapçalament 5',
	tag_h6: 'Encapçalament 6',
	tag_p: 'Normal',
	tag_pre: 'Formatejat'
} );
