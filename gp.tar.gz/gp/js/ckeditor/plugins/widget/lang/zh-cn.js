﻿/**
 * @license Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang( 'widget', 'zh-cn', {
	'move': '点击并拖拽以移动',
	'label': '%1 小部件'
} );
