﻿/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'hu', {
	confirmCleanup: 'Úgy tűnik a beillesztett szöveget Word-ből másolta át. Meg szeretné tisztítani a szöveget? (ajánlott)',
	error: 'Egy belső hiba miatt nem sikerült megtisztítani a szöveget',
	title: 'Beillesztés Word-ből',
	toolbar: 'Beillesztés Word-ből'
} );
